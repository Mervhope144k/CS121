
///////////////////////////////////////////////////////////////////////////////
//
// File Name         : driver.cpp
//
// This program ??????????
//
// Programmer        : B.J. Streller AND WHO ARE YOU ???????????????
//
// Date Written      : in the past
//
// Date Last Revised :
//
///////////////////////////////////////////////////////////////////////////////



#include<iostream>
using namespace::std;

#include "binNum.h"


int main()
{

    /*
      //You test that default consstructor works then remove this code
      BinNum bb;
      cout << " bb is "<< bb << endl;
    */

    /*
      //YOU test that argument constructor works then remove this code
      BinNum bbb( 1101);
      cout << " bbb is  " << bbb << endl;
    */

    /*
      //You test that copy constructor works then remove this code
      BinNum bbbb(bbb);
      cout << " bbbb is  " << bbbb << endl;
    */


    /*
      //test that function call works
      bbbb.foo();
    */


  /*
    //You testing assignment then remove this code
    b2 = b5;
    cout << b7 << endl;
    */

    /*
	//You testing shift function then remove this code
    cout << endl << "shifting \n";
    cout << " b3 : " << b3 << endl;
    BinNum b8;
    cout << " b8 is "<< b8 << endl;
    int shiftNum = 2;
    b8.shiftBinNumBy( shiftNum, b3 );
    cout << b3 << " shifted by  "<< shiftNum << " is "  << b8 << endl;
    */


/*
	//sample driver to run after above works
	
    BinNum b1;
    cout << " enter a binary num : ";
    cin >> b1;
    cout << b1 << endl;


    BinNum b2;
    cout << " enter a binary num : ";
    cin >> b2;
    cout << b2 << endl;


    BinNum b3;
    cout << " enter a binary num : ";
    cin >> b3;
    cout << b3 << endl;


    BinNum b4 = b1 + b2;
    cout << " " <<  b1 << "  +  " << b2 << " = " << b4 << endl;
    cout <<  b1.bin2Base10( ) << "  +  " << b2.bin2Base10( ) << " = " << b4.bin2Base10( ) << endl;



    BinNum b5 = b1 + b2 + b3;
    cout << " " <<  b1 << "  +  " << b2 << "  +  " << b3 <<  " = " << b5 << endl;
    cout << " " <<  b1.bin2Base10( )  << "  +  " << b2.bin2Base10( )  << "  +  " << b3.bin2Base10( )
         <<  " = " << b5.bin2Base10( )  << endl;


	BinNum b111;
    b111 = b3*b4;
    cout << " " <<  b3 << "  *  " << b4 << " = " << b111 << endl;
    cout <<  b3.bin2Base10( ) << "  *  " << b4.bin2Base10( ) << " = " << b111.bin2Base10( ) << endl;

*/
  
    

    return 0;

}


